export const Enviroment = {
    apiUsers: 'api/users',
};
//'https://bulkuploadstests.azurewebsites.net';//
console.log(import.meta.env.VITE_APP_API_URL);
export const API_URL = import.meta.env.VITE_APP_API_URL;