import Typography from "./Typograhpy";

export {
    Typography,
}