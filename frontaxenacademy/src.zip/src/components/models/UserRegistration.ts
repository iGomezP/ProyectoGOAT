interface UserRegistration {
    nickname: string,
    email: string,
    password: string,
    pwd_check: string,
};
export default UserRegistration;