interface ResultObject {
    data?: any;
    message?: string;
    status?: number;
};
export default ResultObject;