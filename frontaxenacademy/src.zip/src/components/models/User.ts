interface User {
    nickname: string,
    email: string,
    password: string,
};
export default User;